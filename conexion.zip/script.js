var j1 = document.querySelector("#j1");


function edit() {
j1.innerText = "Diego Yañez";
}

